from setuptools import setup, find_packages

setup(
    name="repositorioReleases",                     # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Yerson Palacio",                        # Tu nombre
    author_email="ympalacio@celerix.com",           # Tu correo electrónico
    url="https://github.com/YersonPalacio117/repositorioReleases#",     # URL del proyecto
)
